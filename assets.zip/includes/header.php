<?php
$phoneNumber1 = 9717686168;
$phoneNumber2 = 8802555230;
$email1 = "chander@mysticdigi.com";
$email2 = "anubhav@seoserviceinindia.co.in";
$whatsappLink = "yourWhatsappLink";

// social links
$facebook = "yourfacebookLink";
$twitter = "yourtwiitterLink";
$youtube = "yourYoutubeLink";
$linkedin = "yourLinkedinLink";
$pinterest = "yourPitnrestLink";
$instagram = "yourInstagramLink";



// Arrays has been started from here
$seoDrowDownGroup = [

  // link started
  [
    "linkTitle" => "SEO Packages By Industry",


    "links" => [
      [
        "linkName" => "SEO for eCommerce",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Dentists",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Real Estate",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Law Firms/Lawyers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Hotel Websites",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Manufacturers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Healthcare Websites",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Online Casino",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Software Companies",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For IT Companies",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Politicians",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Travel Agency",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Astrology/Astrologers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Movers And Packers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Insurance Companies",
        "url" => "product.php"
      ],


    ]
  ],
  // link started
  [
    "linkTitle" => "SEO Packages By Industry",


    "links" => [
      [
        "linkName" => "SEO for eCommerce",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Dentists",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Real Estate",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Law Firms/Lawyers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Hotel Websites",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Manufacturers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Healthcare Websites",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Online Casino",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Software Companies",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For IT Companies",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Politicians",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Travel Agency",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Astrology/Astrologers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Movers And Packers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Insurance Companies",
        "url" => "product.php"
      ],


    ]
  ],
  // link started
  [
    "linkTitle" => "SEO Packages By Industry",


    "links" => [
      [
        "linkName" => "SEO for eCommerce",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Dentists",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Real Estate",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Law Firms/Lawyers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Hotel Websites",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Manufacturers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Healthcare Websites",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Online Casino",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Software Companies",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For IT Companies",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Politicians",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Travel Agency",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Astrology/Astrologers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Movers And Packers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Insurance Companies",
        "url" => "product.php"
      ],


    ]
  ],
  // link started
  [
    "linkTitle" => "SEO Packages By Industry",


    "links" => [
      [
        "linkName" => "SEO for eCommerce",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Dentists",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Real Estate",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Law Firms/Lawyers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Hotel Websites",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Manufacturers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Healthcare Websites",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Online Casino",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Software Companies",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For IT Companies",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Politicians",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Travel Agency",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO for Astrology/Astrologers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Movers And Packers",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO For Insurance Companies",
        "url" => "product.php"
      ],


    ]
  ],
  // link started
  [
    "linkTitle" => "SEO Packages By Region",
    "links" => [
      [
        "linkName" => "Local SEO Packages",
        "url" => "product.php"
      ],
      [
        "linkName" => "National SEO Packages",
        "url" => "product.php"
      ],
      [
        "linkName" => "International SEO Packages",
        "url" => "product.php"
      ],
    ],
  ],
  // link started
  [
    "linkTitle" => "SEO Packages By Language",
    "links" => [
      [
        "linkName" => "SEO Packages for French Language",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO Packages for German Language",
        "url" => "product.php"
      ],
      [
        "linkName" => "ISEO Packages for Dutch Language",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO Packages for Spanish Language",
        "url" => "product.php"
      ],
      [
        "linkName" => "SEO Packages for Russian Language",
        "url" => "product.php"
      ],
    ],
  ],
  // link started
  [
    "linkTitle" => "App Development Services",
    "links" => [
      [
        "linkName" => "Cricket Live Score App",
        "url" => "product.php"
      ],
     
    ],
  ],


];

$dropDownLinks = [

  // link started
  [
    "linkTitle" => "smo",
    "links" => [
      [
        "linkName" => "Facebook Optimization",
        "url" => "url of link"
      ],
      [
        "linkName" => "Twitter Optimization",
        "url" => "url of link"
      ],
      [
        "linkName" => "LinkedIn Optimization",
        "url" => "url of link"
      ],
      [
        "linkName" => "Instagram Optimization",
        "url" => "url of link"
      ],
      [
        "linkName" => "SMO Packages",
        "url" => "url of link"
      ],
    ]
  ],
  // link started
  [
    "linkTitle" => "smo",
    "links" => [
      [
        "linkName" => "Facebook Optimization",
        "url" => "url of link"
      ],
      [
        "linkName" => "Twitter Optimization",
        "url" => "url of link"
      ],
      [
        "linkName" => "LinkedIn Optimization",
        "url" => "url of link"
      ],
      [
        "linkName" => "Instagram Optimization",
        "url" => "url of link"
      ],
      [
        "linkName" => "SMO Packages",
        "url" => "url of link"
      ],
    ]
  ],
  // link started
  [
    "linkTitle" => "smm",
    "links" => [
      [
        "linkName" => "Facebook Ads",
        "url" => "url of link"
      ],
      [
        "linkName" => "Twitter Ads",
        "url" => "url of link"
      ],
      [
        "linkName" => "LinkedIn Ads",
        "url" => "url of link"
      ],
      [
        "linkName" => "Instagram Ads",
        "url" => "url of link"
      ],
      [
        "linkName" => "iGaming SMM Services",
        "url" => "url of link"
      ],
      [
        "linkName" => "SMM Packages",
        "url" => "url of link"
      ],
    ]
  ],
  // link started
  [
    "linkTitle" => "youtube",
    "links" => [
      [
        "linkName" => "YouTube Monetization Services",
        "url" => "url of link"
      ],
      [
        "linkName" => "Buy YouTube Watch Hours",
        "url" => "url of link"
      ],
      [
        "linkName" => "Buy YouTube Subscribers",
        "url" => "url of link"
      ],
    ]
  ],
  // link started
  [
    "linkTitle" => "ppc",
    "links" => [
      [
        "linkName" => "iGaming/Mobile Gaming PPC",
        "url" => "url of link"
      ],
      [
        "linkName" => "Google Ads Management",
        "url" => "url of link"
      ],
      [
        "linkName" => "Bing Ads Management",
        "url" => "url of link"
      ],
      [
        "linkName" => "PPC Packages",
        "url" => "url of link"
      ],

    ]
  ],
  // link started
  [
    "linkTitle" => "web designing",
    "links" => [
      [
        "linkName" => "Mobile Web Designing",
        "url" => "url of link"
      ],
      [
        "linkName" => "WordPress Web Designing",
        "url" => "url of link"
      ],
      [
        "linkName" => "Shopify Web Designing",
        "url" => "url of link"
      ],
      [
        "linkName" => "Magento Web Designing",
        "url" => "url of link"
      ],
      [
        "linkName" => "eCommerce Web Designing",
        "url" => "url of link"
      ],
      [
        "linkName" => "CMS Web Designing",
        "url" => "url of link"
      ],
      [
        "linkName" => "Portfolio Web Designing",
        "url" => "url of link"
      ],
      [
        "linkName" => "Website Designing Package",
        "url" => "url of link"
      ],
    ]
  ],
  // link started
  [
    "linkTitle" => "web development",
    "links" => [
      [
        "linkName" => "Portfolio Website Development",
        "url" => "url of link"
      ],

    ]
  ],
  // link started
  [
    "linkTitle" => "content",
    "links" => [
      [
        "linkName" => "Content Writing Services",
        "url" => "url of link"
      ],
      [
        "linkName" => "Website Blog Writing Services",
        "url" => "url of link"
      ],
      [
        "linkName" => "Web Service Page Content Writing",
        "url" => "url of link"
      ],
      [
        "linkName" => "eCommerce Products Content",
        "url" => "url of link"
      ],
      [
        "linkName" => "Guest Post Writing",
        "url" => "url of link"
      ],
      [
        "linkName" => "Guest Post Submission",
        "url" => "url of link"
      ],
      [
        "linkName" => "Podcast Submission",
        "url" => "url of link"
      ],
    ]
  ],
  // link started
  [
    "linkTitle" => "hosting",
    "links" => [
      [
        "linkName" => "Shared Web Hosting",
        "url" => "url of link"
      ],
    ]
  ],

];

$normalNavLinks = [
  [
    'linkName' => "Podcast Submission Packages",
    "url" => "nourl"
  ],
  [
    'linkName' => "Google Ads Package",
    "url" => "nourl"
  ],
  [
    'linkName' => "Bing Ads Packages",
    "url" => "nourl"
  ],
  [
    'linkName' => "SMO Packages",
    "url" => "nourl"
  ],
]

  ?>

<header class="d-flex flex-column justify-content-between align-items-center p-0">

  <div
    class="topNav d-flex justify-content-md-start justify-content-between align-items-center px-md-4 px-2 py-2 gap-md-3 gap-2 flex-md-nowrap flex-wrap">

    <div class="logoBox">
      <img src="./assets/img/logo.webp" alt="logo img" />
    </div>

    <!-- <div class="searchBox d-flex justify-content-center align-items-center order-md-0 order-3">
      <input placeholder="i'm looking for" type="text" name="" id="" />
      <button>
        <i class="fa fa-search"></i>
      </button>
    </div> -->
    <div class="freeSEOToolsContainer d-lg-flex d-none mx-md-2 mx-0">
      <span>Our Free SEO Tools</span>
        <a href="#"> Free SEO Tools</a>
    </div>

    

   

    <div class="callBox d-md-flex d-none d-none mx-md-2 mx-0">
      <a class="d-flex align-items-start gap-3" href="tel:+91-<?php echo $phoneNumber1; ?>">
        <i class="fa fa-phone"></i>
        <div class="callBoxDetail d-flex flex-column">
          <span>Customer Support</span>
          <span>+91-
            <?php echo $phoneNumber1; ?>
          </span>
        </div>
      </a>
    </div>
    <a class="d-md-none d-block mobileNoInPhoneView d-none mx-md-2 mx-0" href="tel:<?php echo $phoneNumber1; ?>"><?php echo $phoneNumber1; ?></a>

    <a href="<?php echo $whatsappLink; ?>" class="whatsappButtonRound">
      <i class="fa fa-whatsapp"></i>
    </a>
    <div class="socialLinks d-flex mx-md-2 mx-auto gap-2">
      <a href="<?php echo $facebook; ?>"><i class="fa fa-facebook"></i></a>
      <a href="<?php echo $twitter; ?>"><i class="fa fa-twitter"></i></a>
      <a href="<?php echo $youtube; ?>"><i class="fa fa-youtube-play"></i></a>
      <a href="<?php echo $linkedin; ?>"><i class="fa fa-linkedin"></i></a>
      <a href="<?php echo $pinterest; ?>"><i class="fa fa-pinterest-p"></i></a>
      <a href="<?php echo $instagram; ?>"><i class="fa fa-instagram"></i></a>
      <a href="<?php echo $instagram; ?>"><i class="fa fa-instagram"></i></a>
      <a href="<?php echo $instagram; ?>"><i class="fa fa-instagram"></i></a>
    </div>

    
  </div>

  <!--=================================================================================================================================================================== desktop navbar started -->

  <nav class="d-md-flex d-none">
    <ul class="navLinksContainer">

      <li><a class="navLink" href="/">Home</a></li>


      <li>
        <a href="#" class="navLink">Mega DropDown</a>
        <div class="megaDropBox">

          <?php foreach ($seoDrowDownGroup as $data): ?>

            <div class="megaContentBox">
              <h5><?php echo $data['linkTitle']; ?></h5>
              <ul class="megaLinksBox">
                <?php foreach($data['links'] as $link): ?>
                <li><a href="<?php echo $link['url'] ?>"><?php echo $link['linkName'] ?></a></li>
                <?php endforeach; ?>
              </ul>
            </div>
          <?php endforeach; ?>

          

        </div>
      </li>

      <li class="dropDownToggle">
        <a href="#" class="navLink">Dropdown Menu</a>
        <ul class="dropMenu">
          <li><a href="#">Drop menu 1</a></li>
          <li><a href="#">Drop menu 2</a></li>
          <li><a href="#">Drop menu 3</a></li>
          <li><a href="#">Drop menu 4</a></li>
        </ul>
      </li>

      <li>
        <a href="#" class="navLink">Dropdown Menu</a>
        <ul class="dropMenu">
          <li><a href="#">Drop menu 1</a></li>
          <li><a href="#">Drop menu 2</a></li>
          <li><a href="#">Drop menu 3</a></li>
          <li><a href="#">Drop menu 4</a></li>
        </ul>
      </li>

      <li>
        <a href="#" class="navLink">Dropdown Menu</a>
        <ul class="dropMenu">
          <li><a href="#">Drop menu 1</a></li>
          <li><a href="#">Drop menu 2</a></li>
          <li><a href="#">Drop menu 3</a></li>
          <li><a href="#">Drop menu 4</a></li>
        </ul>
      </li>

      <li>
        <a href="#" class="navLink">Dropdown Menu</a>
        <ul class="dropMenu">
          <li><a href="#">Drop menu 1</a></li>
          <li><a href="#">Drop menu 2</a></li>
          <li><a href="#">Drop menu 3</a></li>
          <li><a href="#">Drop menu 4</a></li>
        </ul>
      </li>

      <li>
        <a href="#" class="navLink">Dropdown Menu</a>
        <ul class="dropMenu">
          <li><a href="#">Drop menu 1</a></li>
          <li><a href="#">Drop menu 2</a></li>
          <li><a href="#">Drop menu 3</a></li>
          <li><a href="#">Drop menu 4</a></li>
        </ul>
      </li>


      <li><a class="navLink" href="/">Contact Us</a></li>
      <li><a class="navLink" href="/">Blog</a></li>
    </ul>
  </nav>




  <!-- ===================================================================================================================================================================================desktop navbar ended -->



















</header>



<!-- dropDown  -->