<section class="serviceBreadCrumbSection d-flex justify-content-center align-items-center">
 
        <div class="serviceBreadCrumbElements">
            <a href="/">home</a>
            /
            <span>
                <?php echo $pageTitle; ?>
            </span>
        </div>

</section>