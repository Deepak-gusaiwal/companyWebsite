<div class="breadCrubmContainer">
    <a href="/">Home</a> <span>/</span>
    <a href="/">Link title</a> <span>/</span>
    <span>Link Name</span> 
</div>