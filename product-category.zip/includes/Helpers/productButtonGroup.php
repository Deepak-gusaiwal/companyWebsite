<div class="productButtonGroup">
    <a href="tel:<?php echo $phoneNumber1; ?>">
        <i class="fa fa-phone" aria-hidden="true"></i>
    </a>

    <a href="mailto:<?php echo $email1 ?>">
        <i class="fa fa-envelope"></i>
    </a>

    <a href="<?php echo $whatsappLink; ?>">
        <i class="fa fa-whatsapp" aria-hidden="true"></i>
    </a>

    <a class="contactFormToogler">
        <i class="fa fa-info-circle" aria-hidden="true"></i>
    </a>
</div>