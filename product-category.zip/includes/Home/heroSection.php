<div class="container-fluid m-0 p-0 heroSectionMasterContainer">
    <div class=" heroSectionSlideContainer">

      <section class="splide heroSplide" aria-label="Splide Slider">
        <div class="splide__track">
          <div class="splide__list">

            <!-- slide-1 -->
            <div class="splide__slide heroSlide">
                <img
                  src="./assets/img/heroSection/seo-1.webp"
                  alt="sliderimg-1"
                />
              <!-- <div class="heroContentBox">
                <h2>We Are Ranked</h2>
                <span class="contentKey">#1</span>
                <span>SEO SERVICES</span>
                <span>SEO SERVICES IN INDIA</span>
              </div> -->
            </div>
            <!-- slide-1 end -->
            

            <!-- slide-2 -->
            <div class="splide__slide heroSlide">
                <img
                  src="./assets/img/heroSection/seo-2.webp"
                  alt="sliderimg-2"
                />
              <!-- <div class="heroContentBox">
                <h2>We Are Ranked</h2>
                <span class="contentKey">#2</span>
                <span>SEO SERVICES</span>
                <span>SEO SERVICES IN INDIA</span>
              </div> -->
            </div>
            <!-- slide-2 end -->


            <!-- slide-3 -->
            <div class="splide__slide heroSlide">
                <img
                  src="./assets/img/heroSection/seo-3.webp"
                  alt="sliderimg-3"
                />
              <!-- <div class="heroContentBox">
                <h2>We Are Ranked</h2>
                <span class="contentKey">#3</span>
                <span>SEO SERVICES</span>
                <span>SEO SERVICES IN INDIA</span>
              </div> -->
            </div>
            <!-- slide-3 end -->

          </div>
        </div>
      </section>
    </div>
  </div>
</div>
