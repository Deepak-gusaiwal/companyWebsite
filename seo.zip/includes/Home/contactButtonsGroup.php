<div
                    class="contactButtonSectionGroup my-2 d-flex flex-wrap justify-content-center align-items-center gap-3">
                    <a href="tel:<?php echo $phoneNumber1 ?>" class="commonButton">
                        <i class="fa fa-phone"></i>
                        <span>Call Us</span>
                    </a>
                    <a href="contact.php" class="commonButton">
                        <i class="fa fa-comments" aria-hidden="true"></i>
                        <span>Fill Our Form</span>
                    </a>
                    <a href="<?php echo $whatsappLink; ?>" class="commonButton">
                        <i class="fa fa-whatsapp"></i>
                        <span>Whatsapp</span>
                    </a>
                    <a href="<?php echo $skype; ?>" class="commonButton">
                        <i class="fa fa-skype" aria-hidden="true"></i>
                        <span>Skype Us</span>
                    </a>
                    <a href="mailto:<?php echo $email1; ?>" class="commonButton">
                        <i class="fa fa-envelope" aria-hidden="true"></i>
                        <span>Email Us</span>
                    </a>
                </div>