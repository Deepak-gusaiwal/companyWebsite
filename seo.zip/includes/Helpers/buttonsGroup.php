<div class="buttonGroup d-flex flex-wrap gap-2 justify-content-center align-items-center">
                    <a href="tel:<?php echo $phoneNumber1 ?>" class="RoundButton callBg">
                        <i class="fa fa-phone"></i>
                    </a>
                    <a href="<?php echo $whatsappLink; ?>" class="RoundButton whatsappBg">
                        <i class="fa fa-whatsapp"></i>
                    </a>
                </div>